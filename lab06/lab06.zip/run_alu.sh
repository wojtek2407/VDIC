#!/bin/bash

./run_xrun.sh -c
